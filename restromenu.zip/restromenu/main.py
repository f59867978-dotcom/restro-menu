menu={
    'coffe':50,
    'pasta':60,
    'pizza':80,
    'burger':50,
    'maggi':60,
    'coldcoffe':90,
    'rice':50,
    'Manchurian':60,
    'kabab paratha ':40,
    'chicken Biryani':90,
    'mutton biryani':180,
    'kabab':40,
    'roti palne':10,
    'Butter roti':15,
    'tanduri roti':12,
    'kabab tikka':80,
    'chicken fry':90,
    'chicken gravi':280,
    'mutton gravi':350,
    'mutton fry':400,
    'salat extra':10,
    'minral water':20,
    'thumsup':20,
    'sprit':20,
    'thumpsup 2litter':90,
    'sprit 2litter':90,
    'limlka 2litter':90,


}
#greet
print("welcom to the Faisal Ali resturant")
print("coffe : Rs50\n pasta:Rs60\n pizza:Rs80\n burger:Rs50\n maggi:Rs60")

order_total=0
#80+70=150
item_1=input("enter your  order if you want order = ")
if item_1 in menu:
    order_total+=menu[item_1] #0+80
    print(f"your item{item_1} have been added in their order")
else:
    print(f"your item {item_1} not in the menu")

    another_order = input("do you want to order another item (yes/No):")
if 'another_order' == "Yes":
    item_2 =input("enter the name of second item= ")
if 'item_2'in menu:
    order_total+=menu[item_2] 
    print(f"item {item_2} added in the order")
else:
    print(f"order item[item2]is not avaialable  ")
    print(f"your total amount of item to pay(order_total)")
    print(" thank you for wisiting from my resturant")




       

